<?php

/**
 * @file santander_loan.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-11
 */

// This file is required. All language text is in the Low Level API