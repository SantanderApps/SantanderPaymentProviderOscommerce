<?php

/**
 * @file santander.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-11
 */

require('includes/application_top.php');
require DIR_WS_MODULES . 'payment/santander/includes.php';
Santander::run(new Santander_APIConnector());
if (Santander::$api->config->getAccessLogExternal()) {
    print Santander::$logger->getLogFile((int)$_GET['d']);
}

require(DIR_WS_INCLUDES . 'application_bottom.php');