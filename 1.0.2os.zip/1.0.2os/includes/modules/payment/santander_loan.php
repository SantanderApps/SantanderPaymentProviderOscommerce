<?php

/**
 * santander
 *
 * @file santander.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-10
 * 
 * Sandbox user details:
 * Store ID: EasyStubTesters
 * Username: testbutik1
 * Password: testbutik1
 */

require_once __DIR__ . '/santander/includes.php';

class santander_loan {
    var $code, $title, $description, $enabled;
    
    var $_santander_order_number;
    
    /**
     * @var \Santander\models\Result 
     */
    var $_result;
    
    const STATUS_TEST = 'sandbox (test environment)';
    const STATUS_LIVE = 'live';
    
    function santander_loan() {
        global $order;
        
        Santander::run(new Santander_APIConnector());
        
        $this->code = 'santander_loan';
        $test_mode = self::STATUS_TEST;
        $this->title = <<<JAVASCRIPT
            <script type="text/javascript">
                if (window.addEventListener) {
                    window.addEventListener('load', initSantanderModule);
                } else if (window.attachEvent) {
                    window.attachEvent('onload', initSantanderModule);
                }

                var initSantanderModule = function() {
                    var form = document.getElementsByName('modules')[0];
            
                    if (typeof form === "undefined") {
                        return false;
                    }
            
                    var radio_buttons = form.elements['configuration[MODULE_PAYMENT_SANTANDER_LOAN_MODE]'];
            
                    for (var i=0; i<radio_buttons.length; i++) {
                        if (radio_buttons[i].addEventListener) {
                            radio_buttons[i].addEventListener('change', santanderPopulateFields);
                        } else if (radio_buttons[i].attachEvent) {
                            radio_buttons[i].attachEvent('onchange', santanderPopulateFields);
                        }
                    }
            
                    santanderPopulateFields();
                };
                    
                var santanderPopulateFields = function() {
                    var form = document.getElementsByName('modules')[0],
                        radio_buttons = form.elements['configuration[MODULE_PAYMENT_SANTANDER_LOAN_MODE]'],
                        store_id_field = form.elements['configuration[MODULE_PAYMENT_SANTANDER_LOAN_STORE_ID]'],
                        username_field = form.elements['configuration[MODULE_PAYMENT_SANTANDER_LOAN_USERNAME]'],
                        password_field = form.elements['configuration[MODULE_PAYMENT_SANTANDER_LOAN_PASSWORD]'],
                        certificate_field = form.elements['configuration[MODULE_PAYMENT_SANTANDER_LOAN_CERTIFICATE_NAME]'],
                        mode;
                    for (var i=0; i<radio_buttons.length; i++) {
                        if (radio_buttons[i].checked) {
                            mode = radio_buttons[i].value;
                        }
                    }
            
                    if (mode == '{$test_mode}') {
                        store_id_field.value = 'EasyStubTesters';
                        username_field.value = 'testbutik1';
                        password_field.value = 'testbutik1';
                    } else {
                        store_id_field.value = '';
                        username_field.value = '';
                        password_field.value = '';
                        certificate_field.value = '';
                    }
                }
            </script>
JAVASCRIPT;
        $this->title .= Santander::$api->_('Santander Consumer Bank');
        $this->public_title = Santander::$api->_('Santander Consumer Bank');
        $this->description = $this->getDescription();
        $this->sort_order = MODULE_PAYMENT_SANTANDER_LOAN_SORT_ORDER;
        $this->enabled = ((MODULE_PAYMENT_SANTANDER_LOAN_STATUS == 'True') ? TRUE : FALSE);
        $this->_payment_method_image = 'logo.png';
        
        if ((int)MODULE_PAYMENT_SANTANDER_PREPARE_ORDER_STATUS_ID > 0) {
            $this->order_status = MODULE_PAYMENT_SANTANDER_LOAN_PREPARE_ORDER_STATUS_ID;
        }
        
        if (is_object($order)) $this->update_status();
    }
    
    function update_status() {
        global $order;
        
        if (($this->enabled == TRUE) && ((int)MODULE_PAYMENT_SANTANDER_LOAN_ZONE > 0)) {
            $check_flag = FALSE;
            $check_query = tep_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_SANTANDER_LOAN_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
            while ($check = tep_db_fetch_array($check_query)) {
                if ($check['zone_id'] < 1) {
                    $check_flag = TRUE;
                    break;
                } elseif ($check['zone_id'] == $order->billing['zone_id']) {
                    $check_flag = TRUE;
                    break;
                }
            }
            
            if ($check_flag == FALSE) {
                $this->enabled = FALSE;
            }
        }
        // The payment method is not available for companies
        elseif (!empty($order->billing['company'])) {
            $this->enabled = FALSE;
        }
    }
    
    function javascript_validation() {
        return FALSE;
    }
    
    function pre_confirmation_check() {
        global $cartID, $cart, $order;
        
        $this->_santander_order_number = $cartID;
        
        /**
         * Create a unqiue cart ID for use as value for the orderNumber attribute 
         * to getToken() method of the API.
         */
        if (empty($cart->cartID)) {
            $cartID = $this->_santander_order_number = $cart->generate_cart_id();
        }
        
        if (!tep_session_is_registered('cartID')) {
            tep_session_register('cartID');
        }
      
        /**
         * Calculate the purchase amount for use as the value for the purchaseAmount
         * attribute to getToken method of the API.
         */
        $order->cart();
        $purchase_amount = $order->info['total'];
        $token = Santander::$api->getToken($this->_santander_order_number, $purchase_amount);
        
        /**
         * If we got a token we set the form URL to the Easy Website
         */
        if ($token != null && $token->isOk) {
            $this->form_action_url = Santander::$api->config->getRedirectUrl($token->token);
        }
        elseif (!$token) {
            tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode(Santander::$api->_('An error occured while communicating with Santander Consumer Bank. Try again or choose another payment method.'))));
        }
        else {
            /**
             * If we did not get a token we redirect the user back to the 
             * checkout payment page.
             */
            tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode($token->errorMessage)));
        }
    }
    
    function confirmation() {
        return FALSE;
    }
    
    function selection() {
        return array(
            'id' => $this->code,
            'module' => $this->public_title . (!empty($this->_payment_method_image) ? '<br />' . tep_image('ext/santander/src/assets/images/' . $this->_payment_method_image, $this->public_title) : ''),
        );
    }
    
    function process_button() {
        return FALSE;
    }
    
    function before_process() {
        global $cartID, $order;
        
        $this->_santander_order_number = $cartID;
        $this->_result = Santander::$api->getResult($_GET['token'], $cartID);
        
        /**
         * If an error, i.e no connection with the webservice, we redirect the
         * customer back to checkout payment page.
         */
        if (!$this->_result) {
            tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode(Santander::$api->_('An error occured while communicating with Santander Consumer Bank. Try again or choose another payment method.'))));
        }
        /**
         * If we did not got any good result we redirect the customer back to the
         * checkout payment page.
         */
        elseif (!$this->_result->isOk) {
            tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode($this->_result->humanFailureMessage)));
        }
        /**
         * If we got a good result we change the billing address in the $order
         * object to match the address returned from the web service.
         */
        elseif (!empty($this->_result->address->firstName)) {
            $order->billing['firstname'] = $this->_result->address->firstName;
            $order->billing['lastname'] = $this->_result->address->lastName;
            $order->billing['street_address'] = $this->_result->address->address;
            $order->billing['city'] = $this->_result->address->city;
            $order->billing['postcode'] = $this->_result->address->postCode;
            $order->billing['company'] = '';
            $order->billing['suburb'] = '';
            $order->billing['state'] = '';
        }
    }
    
    function after_process() {
        Santander::$api->finishOrder(array($this, 'finish_order'));
    }
    
    function get_error() {
        return FALSE;
    }
    
    function check() {
      if (!isset($this->_check)) {
        $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_SANTANDER_LOAN_STATUS'");
        $this->_check = tep_db_num_rows($check_query);
      }
      return $this->_check;
    }
    
    function install() {
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Enable Santander Consumer Bank module', 'MODULE_PAYMENT_SANTANDER_LOAN_STATUS', 'True', 'Do you want to enable the Santander Consumer Bank payment method?', '6', '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) VALUES ('Payment Zone', 'MODULE_PAYMENT_SANTANDER_LOAN_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '2', 'tep_get_zone_class_title', 'tep_cfg_pull_down_zone_classes(', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Sort order of display.', 'MODULE_PAYMENT_SANTANDER_LOAN_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '0', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) VALUES ('Set Order Status', 'MODULE_PAYMENT_SANTANDER_LOAN_PREPARE_ORDER_STATUS_ID', '0', 'Set the status of orders made with this payment module to this value', '6', '0', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Set Module Environment', 'MODULE_PAYMENT_SANTANDER_LOAN_MODE', '" . self::STATUS_TEST . "', 'In what environment will you run the module?', '6', '5', 'tep_cfg_select_option(array(\'" . self::STATUS_TEST . "\', \'" . self::STATUS_LIVE . "\'), ', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Store ID', 'MODULE_PAYMENT_SANTANDER_LOAN_STORE_ID', 'EasyStubTesters', 'Type the store ID given to you by Santander Consumer Bank.', '6', '6', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Username', 'MODULE_PAYMENT_SANTANDER_LOAN_USERNAME', 'testbutik1', 'Type the username given to you by Santander Consumer Bank.', '6', '7', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Password', 'MODULE_PAYMENT_SANTANDER_LOAN_PASSWORD', 'testbutik1', 'Type the password given to you by Santander Consumer Bank.', '6', '8', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Merchant ID', 'MODULE_PAYMENT_SANTANDER_LOAN_MERCHANT_ID', '', 'Type the merchant ID given to you by your payment service provider.', '6', '9', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Support Logs', 'MODULE_PAYMENT_SANTANDER_LOAN_ACCESS_LOGS', 'True', 'For a better support experience Santander´s plugin logs all connections to and from Santander´s web services. You have the option to opt-out of these logs being automatically collected by Santander.', 6, 10, 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
        tep_db_query("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Installation date', 'MODULE_PAYMENT_SANTANDER_INSTALLATION_DATE', '" . date('Y-m-d H:i') . "', 'Installation date', '6', '0', now())");
    }
    
    function remove() {
        tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
        tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_SANTANDER_INSTALLATION_DATE'");
    }
    
    function keys() {
        return array(
            'MODULE_PAYMENT_SANTANDER_LOAN_STATUS',
            'MODULE_PAYMENT_SANTANDER_LOAN_SORT_ORDER',
            'MODULE_PAYMENT_SANTANDER_LOAN_PREPARE_ORDER_STATUS_ID',
            'MODULE_PAYMENT_SANTANDER_LOAN_ZONE',
            'MODULE_PAYMENT_SANTANDER_LOAN_MODE',
            'MODULE_PAYMENT_SANTANDER_LOAN_STORE_ID',
            'MODULE_PAYMENT_SANTANDER_LOAN_USERNAME',
            'MODULE_PAYMENT_SANTANDER_LOAN_PASSWORD',
            'MODULE_PAYMENT_SANTANDER_LOAN_MERCHANT_ID',
            'MODULE_PAYMENT_SANTANDER_LOAN_ACCESS_LOGS',
        );
    }
    
    function getDescription() {
        $description = '';
        $parsed = explode('/', $_SERVER['SCRIPT_NAME']);
        $is_admin = (isset($parsed[0]) && ($parsed[0] == 'admin' || $parsed[1] == 'admin'));
        
        if ($is_admin && $this->check()) {
            $description .= '<p><img src="images/icon_info.gif" border="0" />&nbsp;' . Santander::$api->_('<strong>Version:</strong> {versionNumber}', array('versionNumber' => Santander::$api->config->getModuleVersion())) . '</p>';
            $description .= '<p><img src="images/icon_info.gif" border="0" />&nbsp;<a href="' . tep_href_link(FILENAME_MODULES, 'set=payment&module=santander_loan&connection_test=1') . '" style="text-decoration:underline;">' . Santander::$api->_('Test connection with the web service') . '</a></p>';

            if (isset($_GET['connection_test']) && (bool)$_GET['connection_test']) {
                require_once DIR_FS_CATALOG_MODULES . 'payment/santander/includes.php';
                Santander::run(new Santander_APIConnector());

                $wsdlConnection = Santander::$api->getTransferInformation();
                $sfConnection = Santander::$api->getTransferInformation('sf');

                if ($wsdlConnection['success']) {
                    $description .= '<div class="secSuccess"><p>' . Santander::$api->_('Success! Connected to {host}', array('{host}' => parse_url($wsdlConnection['info']['url'], PHP_URL_HOST))) . '</p></div>';
                }
                else {
                    $description .= '<div class="secError">' . Santander::$api->_('<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>', array('{host}' => parse_url($wsdlConnection['info']['url'], PHP_URL_HOST))) . '</div>';
                }

                if ($sfConnection['success']) {
                    $description .= '<div class="secSuccess"><p>' . Santander::$api->_('Success! Connected to {host}', array('{host}' => parse_url($sfConnection['info']['url'], PHP_URL_HOST))) . '</p></div>';
                }
                else {
                    $description .= '<div class="secError">' . Santander::$api->_('<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>', array('{host}' => parse_url($sfConnection['info']['url'], PHP_URL_HOST))) . '</div>';
                }
            }
            
            $description .= '<p><img src="images/icon_info.gif" border="0" />&nbsp;<a href="' . tep_href_link(FILENAME_MODULES, 'set=payment&module=santander_loan&verify_details=1') . '" style="text-decoration:underline;">' . Santander::$api->_('Verify user details') . '</a><br><span style="color:red;">' . Santander::$api->_('<strong>Note:</strong> Only available when "Module Environment" is set to "{statusLive}".', array('statusLive' => self::STATUS_LIVE)) . '</span></p>';
            
            if (isset($_GET['verify_details']) && (bool)$_GET['verify_details']) {
                require_once DIR_FS_CATALOG_MODULES . 'payment/santander/includes.php';
                Santander::run(new Santander_APIConnector());
                
                if (Santander::$api->testConnection(uniqid())) {
                    $description .= '<div class="secSuccess"><p>' .Santander::$api->_('Success! The test connection with the web service works great. Your account details is correct.') . '</p></div>';
                }
                else {
                    $description .= '<div class="secError"><p>' . Santander::$api->_('Error! The test connection with the web service failed. It seems like your account details are incorrect. Make sure that they are correct, if it still doesn\'t work please {contactUs}.', array('contactUs' => '<a href="' . Santander::$api->config->getClientSiteUrl() . '" target="_blank"><u>contact us</u></a>')) . '</p></div>';
                }
            }
        }
        
        return $description;
    }
    
    function finish_order() {
        global $insert_id, $order;
        
        // Add a comment to the order with the string used as the parameter 
        // StoreIdentifier with the call to GetToken
        $sql_data_array = array(
            'orders_id' => $insert_id,
            'orders_status_id' => $order->info['order_status'],
            'date_added' => 'now()',
            'customer_notified' => 0,
            'comments' => Santander::$api->_('Santander Consumer Bank order number: {orderNumber}', array('orderNumber' => $this->_santander_order_number)),
        );
        tep_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
        
        // Add a comment to the order with the AuthorizationCode coming from the
        // GetResult request
        $sql_data_array = array(
            'orders_id' => $insert_id,
            'orders_status_id' => $order->info['order_status'],
            'date_added' => 'now()',
            'customer_notified' => 0,
            'comments' => Santander::$api->_('Authorization receipt to be used when capturing the amount from your payment service provider: {authorizationCode}', array('authorizationCode' => $this->_result->authorizationCode)),
        );
        tep_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
    }
}
