<?php

/**
 * GetToken
 *
 * @file GetToken.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-04
 */

namespace Santander\soap\actions;

class GetToken {
    public $request; // GetTokenRequest
}
