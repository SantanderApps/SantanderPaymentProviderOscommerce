<?php

/**
 * @file en-GB.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-04
 */

return array(
    // General
    'Santander Consumer Bank' => 'Santander Consumer Bank',
    '<strong>Version:</strong> {versionNumber}' => '<strong>Version:</strong> {versionNumber}',
    
    // Check requirements
    'PHP version (5.3.0 or greater)' => 'PHP version (5.3.0 or greater)', 
    'valid ({phpVersion})' => 'valid ({phpVersion})',
    'invalid ({phpVersion})' => 'invalid ({phpVersion})',
    'PHP SoapClient class' => 'PHP SoapClient class',
    'exists' => 'exists',
    'not exist' => 'not exist',
    'cURL' => 'cURL',
    'enabled' => 'enabled',
    'not enabled' => 'not enabled',
    
    // Module Configuration
    'Santander Consumer Bank order number: {orderNumber}' => 'Santander Consumer Bank order number: {orderNumber}', 
    'Available Markets' => 'Available Markets',
    'Sweden' => 'Sweden',
    'Denmark' => 'Denmark',
    'Norway' => 'Norway',
    'Finland' => 'Finland',
    'Great Britain' => 'Great Britain',
    'Test connection with the web service' => 'Test connection with the web service',
    'Success! Connected to {host}' => 'Success! Connected to {host}',
    '<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>' => '<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>',
    'Success! Connected to {host}' => 'Success! Connected to {host}',
    '<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>' => '<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>',
    'Verify user details' => 'Verify user details',
    '<strong>Note:</strong> Only available when "Module Environment" is set to "{statusLive}".' => '<strong>Note:</strong> Only available when "Module Environment" is set to "{statusLive}".',
    
    // Log mail
    'Log file from {system}' => 'Log file from {system}', 
    'Log file from {yesterday} for {system} is attached in this e-mail.' => 'Log file from {yesterday} for {system} is attached in this e-mail.',
    
    // Checkout error messages
    'An error occured while communicating with Santander Consumer Bank. Try again or choose another payment method.' => 'An error occured while communicating with Santander Consumer Bank. Try again or choose another payment method.',
    'RETURN_CODE_DESCRIPTION_105' => 'An unexpected technical issue has occured.',
    'RETURN_CODE_DESCRIPTION_110' => 'An unexpected technical issue has occured.',
    'RETURN_CODE_DESCRIPTION_200' => 'You have choosen to cancel the application (kod 200)',
    'RETURN_CODE_DESCRIPTION_201' => 'You have choosen to cancel the application (kod 201)',
    'RETURN_CODE_DESCRIPTION_202' => 'You have choosen to cancel the application (kod 202)',
    'RETURN_CODE_DESCRIPTION_203' => 'You have choosen to cancel the application (kod 203)',
    'RETURN_CODE_DESCRIPTION_204' => 'You have choosen to cancel the application (kod 204)',
    'RETURN_CODE_DESCRIPTION_207' => 'You have choosen to cancel the application (kod 207)',
    'RETURN_CODE_DESCRIPTION_210' => 'You have already started an application. Call Santander Consumer Bank if you wish to complete your application (kod 210)',
    'RETURN_CODE_DESCRIPTION_211' => 'An unexpected technical issue has occured. Please, inform the shop owner (kod 211)',
    'RETURN_CODE_DESCRIPTION_300' => 'An unexpected technical issue has occured. Please, inform the shop owner (kod 300)',
    'RETURN_CODE_DESCRIPTION_909' => 'An unexpected technical issue has occured. Please, inform the shop owner (felkod 909)',
    'RETURN_CODE_DESCRIPTION_310' => 'An unexpected technical issue has occured. Please, inform the shop owner (kod 310)',
);