<?php

/**
 * @file i18n_csv_converter.php
 * @author Söderlind Media
 * @version 1.0.0
 * @created 2015-sep-07
 */

define('WEB_ROOT', __DIR__);

require __DIR__ . '/../src/autoloader.php';
require __DIR__ . '/../example/includes/includes.php';
require __DIR__ . '/../src/Santander.php';
Santander::run(new Connector()); // Kickstart the API

$dir = new DirectoryIterator(SANTANDER_LIB_PATH . DIRECTORY_SEPARATOR . 'i18n' . DIRECTORY_SEPARATOR . 'messages');
foreach ($dir as $fileInfo) {
    if (!$fileInfo->isDot() && $fileInfo->isFile()) {
        print 'Processing ' . $fileInfo->getFilename() . PHP_EOL;
        
        $langCode = explode('.', $fileInfo->getFilename())[0];
        $dirname = __DIR__ . DIRECTORY_SEPARATOR . 'locale' . DIRECTORY_SEPARATOR . $langCode;
        
        if (!is_dir($dirname)) {
            mkdir($dirname, 0770, true);
        }
        
        $text = require $fileInfo->getPathname();
        $csv = '';
        foreach ($text as $key => $string) {
            $csv .= '"' . addslashes($key) . '","' . addslashes($string) .'"' . PHP_EOL;
        }
        
        if (file_put_contents($dirname . DIRECTORY_SEPARATOR . 'Santander_EasyContract.csv', $csv)) {
            print 'Written csv to ' . $dirname . DIRECTORY_SEPARATOR . 'Santander_EasyContract.csv' . PHP_EOL;
        }
        else {
            print 'Failed to write csv to ' . $dirname . DIRECTORY_SEPARATOR . 'Santander_EasyContract.csv' . PHP_EOL;
        }
        
        print PHP_EOL;
    }
}